create trigger NEW_CLINIC
    before insert
    on CLINIC
    for each row
BEGIN
  SELECT Clinic_ID_sequence.nextval
  INTO :new.ID
  FROM dual;
END;
/

