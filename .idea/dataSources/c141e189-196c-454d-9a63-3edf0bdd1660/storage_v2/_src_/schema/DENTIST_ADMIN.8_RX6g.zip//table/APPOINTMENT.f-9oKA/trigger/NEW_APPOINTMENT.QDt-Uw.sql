create trigger NEW_APPOINTMENT
    before insert
    on APPOINTMENT
    for each row
BEGIN
  SELECT APPOINTMENT_ID_sequence.nextval
  INTO :new.ID
  FROM dual;
END;
/

